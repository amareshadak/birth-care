import React from "react";

function Registration() {
  return <div>registration page</div>;
}

export default Registration;
