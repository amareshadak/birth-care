import React from "react";

function Login() {
  return <div>login page</div>;
}

export default Login;
